(()=>{
'use strict';
const current=new URL(document.currentScript.src).searchParams.get('v');
const key='mcore-update-target';
let busy=false, timer=0, target='', notice;
const frames=new WeakSet();
let lastMutation=0;
function mark(e){const t=e.target;if(!t?.closest)return;if(e.type==='submit'||(e.type==='click'&&t.closest('button')&&/儲存|刪除|上移|下移|發布|同步|匯入|初始化|登入|登出|^[↑↓]$/.test(t.closest('button').textContent.trim()))||(e.type==='change'&&t.matches('input[type=file]')))lastMutation=Date.now();}
function watch(doc){for(const type of ['change','click','submit'])doc.addEventListener(type,mark,true);}
watch(document);
function watchFrames(){for(const f of document.querySelectorAll('iframe')){if(!frames.has(f)){frames.add(f);const attach=()=>{try{if(f.contentDocument)watch(f.contentDocument)}catch{}};f.addEventListener('load',attach);attach();}}}
watchFrames();
function editing(){if(window.mcorePendingWrites>0||Date.now()-lastMutation<20000||document.querySelector('dialog[open],details[open][data-mcore-auth-panel],details[data-mcore-editor][open]'))return true;for(const f of document.querySelectorAll('iframe')){try{const d=f.contentDocument;if(d?.documentElement?.dataset.mcoreSaving==='true'||d?.documentElement?.dataset.mcoreEditing==='true'||d?.querySelector('dialog[open]'))return true}catch{}}return false;}
function reload(version){const u=new URL(location.href);u.searchParams.set('mcore_v',version);u.searchParams.set('mcore_t',String(Date.now()));try{sessionStorage.setItem(key,version)}catch{}location.replace(u.href);}
function offer(version){target=version;if(notice)return;notice=document.createElement('div');notice.style.cssText='position:fixed;bottom:calc(12px + env(safe-area-inset-bottom));left:12px;right:12px;max-width:440px;margin:auto;z-index:99999;background:#fffaf8;color:#875b6a;border:1px solid #e5cbd0;border-radius:14px;padding:12px;box-shadow:0 3px 18px #0002;font:14px system-ui';notice.setAttribute('role','status');const msg=document.createElement('span');msg.textContent='網站有新版，請先完成並儲存編輯，再更新。';const b=document.createElement('button');b.type='button';b.textContent='更新網站';b.style.cssText='margin-left:8px;padding:7px 10px;border:0;border-radius:9px;background:#ce8999;color:white;font:inherit';b.onclick=()=>{if(confirm('請確認所有編輯已儲存，現在更新網站？'))reload(target)};notice.append(msg,b);document.body.append(notice);}
async function check(){if(busy||document.visibilityState==='hidden'||navigator.onLine===false)return;busy=true;try{const u=new URL('./version.json',location.href);u.searchParams.set('_',String(Date.now()));const r=await fetch(u.href,{cache:'no-store'});if(!r.ok)return;const v=(await r.json()).version;if(typeof v!=='string'||!/^V\d+(?:-RC\d+)?$/.test(v)||!current)return;if(v===current){notice?.remove();notice=null;try{sessionStorage.removeItem(key)}catch{}return;}let previous='';try{previous=sessionStorage.getItem(key)||''}catch{}if(previous===v&&new URL(location.href).searchParams.get('mcore_v')===v){offer(v);return;}if(editing())offer(v);else reload(v);}catch{}finally{busy=false}}
function schedule(){clearTimeout(timer);timer=setTimeout(check,350)}
window.addEventListener('pageshow',schedule);window.addEventListener('focus',schedule);window.addEventListener('online',schedule);document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')schedule()});setInterval(check,60000);setInterval(()=>{if(notice&&!editing())check()},5000);schedule();
})();
