(()=>{
const groups={itineraries:['days'],travelInfo:['info','hotels','metro','emergency']};
const schema='V082-text-v1';
const records=[];
for(const [collection,ids] of Object.entries(groups))for(const id of ids){
 const root=document.getElementById(id);if(!root)continue;
 const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);const nodes=[];let n;
 while(n=walker.nextNode()){if(n.nodeValue.trim()&&!n.parentElement.closest('script,style,button,input,select,textarea,.tabs'))nodes.push(n)}
 const baseline=nodes.map(n=>n.nodeValue);records.push({collection,id,nodes,baseline,revision:null,loaded:false});
}
const panel=document.createElement('details');panel.dataset.mcoreEditor='true';panel.style.cssText='margin:16px auto;max-width:720px;padding:12px;font:13px system-ui';
const summary=document.createElement('summary');summary.textContent='每日行程／旅行資訊雲端管理';panel.append(summary);
const status=document.createElement('p');status.setAttribute('aria-live','polite');panel.append(status);
const admin=document.createElement('div');admin.hidden=true;panel.append(admin);
const select=document.createElement('select');for(const r of records){const o=document.createElement('option');o.value=r.id;o.textContent=r.id;select.append(o)}admin.append(select);
const fields=document.createElement('div');admin.append(fields);
const make=(label,fn)=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.onclick=fn;return b};
const report=t=>status.textContent=t;
const selected=()=>records.find(r=>r.id===select.value);
function editor(){fields.replaceChildren();const r=selected();if(!r?.loaded)return;for(const [i,n] of r.nodes.entries()){const label=document.createElement('label');label.style.display='block';label.textContent=`${i+1}. `;const input=document.createElement('textarea');input.rows=2;input.style.width='100%';input.value=n.nodeValue;label.append(input);fields.append(label)}}
select.onchange=editor;
const ref=(fs,db,r)=>fs.doc(db,r.collection,'shanghai-suzhou-'+r.id);
function validate(r,d){return d.schema===schema&&Array.isArray(d.values)&&d.values.length===r.nodes.length&&d.values.every(v=>typeof v==='string')&&Number.isInteger(d.revision)&&d.revision>0}
async function load(){const {fs,db}=await window.mcoreCloud.ready();let count=0,errors=[];await Promise.all(records.map(async r=>{try{const s=await fs.getDocFromServer(ref(fs,db,r));if(s.exists()){const d=s.data();if(!validate(r,d))throw Error('資料格式不符');d.values.forEach((v,i)=>r.nodes[i].nodeValue=v);r.revision=d.revision;count++}else{r.baseline.forEach((v,i)=>r.nodes[i].nodeValue=v);r.revision=null}r.loaded=true}catch(e){r.loaded=false;errors.push(r.id+': '+(e.code||e.message))}}));editor();report(`已讀取 ${count}/${records.length} 份雲端資料；未初始化頁面保留原始內容。${errors.length?' 讀取失敗：'+errors.join('；'):''}`)}
async function save(r,values){const {fs,db,a}=await window.mcoreCloud.ready();if(!window.mcoreCloud.isAdmin()||!a.currentUser)throw Error('請先登入管理員');if(!r.loaded)throw Error('請先成功讀取雲端');if(new TextEncoder().encode(JSON.stringify(values)).length>850000)throw Error('資料過大');const revision=await fs.runTransaction(db,async tx=>{const doc=ref(fs,db,r),s=await tx.get(doc);if(s.exists()&&!validate(r,s.data()))throw Error('既有資料格式不符');const actual=s.exists()?s.data().revision:null;if(actual!==r.revision)throw Error('雲端已更新，請重新讀取');const revision=(actual??0)+1;tx.set(doc,{schema,values,revision});return revision});r.revision=revision;values.forEach((v,i)=>r.nodes[i].nodeValue=v)}
admin.append(make('儲存本頁文字',async()=>{try{const r=selected();const values=Array.from(fields.querySelectorAll('textarea'),x=>x.value);if(values.length!==r.nodes.length)throw Error('請先讀取');await save(r,values);report('本頁已儲存')}catch(e){report(e.message)}}));
admin.append(make('初始化尚未建立的頁面',async()=>{if(!confirm('只建立尚未存在的頁面，不覆蓋既有雲端資料。繼續？'))return;let count=0,errors=[];for(const r of records.filter(x=>x.loaded&&x.revision===null)){try{await save(r,r.baseline);count++}catch(e){errors.push(r.id+': '+e.message)}}report(`建立 ${count} 頁。${errors.join('；')}`);editor()}));
panel.append(make('重新讀取雲端',()=>load().catch(e=>report(e.message))));document.body.append(panel);panel.hidden=true;
for(const r of records){const b=make(r.collection==='travelInfo'?'編輯旅行資訊':'編輯行程總覽',()=>{select.value=r.id;editor();panel.hidden=false;panel.open=true;panel.scrollIntoView({block:'center'});});b.className='mcore-admin';document.getElementById(r.id).querySelector('.card').prepend(b);}

new MutationObserver(()=>{admin.hidden=!window.mcoreCloud.isAdmin()}).observe(document.body,{attributes:true,attributeFilter:['class']});admin.hidden=!window.mcoreCloud.isAdmin();load().catch(e=>report('雲端未連線，保留原始資料：'+e.message));
})();
