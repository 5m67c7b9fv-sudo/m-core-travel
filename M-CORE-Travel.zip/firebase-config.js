export const firebaseConfig = Object.freeze({
  "apiKey": "AIzaSyA48gm0pyBuCObhDzYrzMa-waIh26R2Seo",
  "authDomain": "m-core-travel.firebaseapp.com",
  "projectId": "m-core-travel",
  "storageBucket": "m-core-travel.firebasestorage.app",
  "messagingSenderId": "639023552337",
  "appId": "1:639023552337:web:557b7cc4916fda18cc2570"
});
if (firebaseConfig.projectId !== "m-core-travel") throw new Error("Unexpected Firebase project");
