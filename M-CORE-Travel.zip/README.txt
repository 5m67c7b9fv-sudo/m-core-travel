V090-RC8｜正式 Firebase m-core-travel 測試候選版
解壓縮，將 index.html 與同層 JS 檔案完整上傳至 GitHub Pages 網站根目錄。不要只上傳 index.html。
開啟 HTTPS 網址，展開頁末「正式 Firebase 連線驗證」，先未登入檢查五個集合讀取，再登入指定管理員。
行程／旅行資訊：頁末雲端管理初始化尚未建立頁面。行李：發布清單。探索指南：逐筆儲存或匯入舊備份。旅費：確認備份後匯入，勿輸入私密資料（公開讀取）。
測試修改、重新整理、另一裝置讀取；確認登出不能寫入。保留舊站及備份直至驗收。
目前僅有靜態檢查，瀏覽器導航受政策阻擋，Firebase 尚未實測。不使用 Storage，不需要修改現有 Rules。

V102: Future releases must update version.json version, auto-update.js current, and local script version query strings together. After any interaction update requires confirmation to protect unsaved edits.

V103-RC21: hourly weather, city tabs, itinerary switch on 2026-11-22. Live device/API verification pending.
